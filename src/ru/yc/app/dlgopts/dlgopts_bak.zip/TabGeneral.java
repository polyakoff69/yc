package ru.pcom.app.dlgopts;

import javafx.geometry.Insets;
import javafx.scene.control.Label;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.Region;
import ru.pcom.app.Config;
import ru.pcom.app.ICallback;

import java.util.ResourceBundle;

public class TabGeneral implements ICallback {

    public Region buildTab(ResourceBundle rs, DlgOptions parent){
        Config cfg = Config.get();

        GridPane pane = new GridPane();
        pane.getStyleClass().add("dlg-tab-container");
        pane.setPadding(new Insets(0));
        pane.setHgap(5);
        pane.setVgap(5);
        // pane.setStyle("-fx-border-color: #000000; -fx-border-width: 1 1 1 1");

        Label lab = new Label("TODO:");
        pane.add(lab,0,0);

        return pane;
    }

    public Object onAction(Object o){
        Config cfg = (Config)o;
        //
        return o;
    }

}
